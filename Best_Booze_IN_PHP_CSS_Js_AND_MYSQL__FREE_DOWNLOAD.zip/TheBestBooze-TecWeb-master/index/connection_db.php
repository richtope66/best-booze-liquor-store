<?php
$host = 'localhost';
$user = 'root';
$db = 'gdelmoro';
$password = '';
$conn= new mysqli($host, $user, $password, $db);
if ($conn->connect_errno) {
echo "Connessione fallita (". $conn->connect_errno
. "): " . $conn->connect_error;
exit();
}
?>
