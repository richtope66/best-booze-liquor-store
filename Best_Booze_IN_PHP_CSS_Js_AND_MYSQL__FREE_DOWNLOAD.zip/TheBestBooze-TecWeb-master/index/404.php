<?php
echo file_get_contents("html/404.html");
?>
